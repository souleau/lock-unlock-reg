# Locker and Unlocker

just for fun I did this quickly

## Utilisation

-1 in the locker you have to click on a button to lock it, 
  once the button is clicked you just have to close the app 
  ( if the application is locked you will no longer be able to launch it )

-2 to unlock the app you just have to open unlocker and you can open locker again
