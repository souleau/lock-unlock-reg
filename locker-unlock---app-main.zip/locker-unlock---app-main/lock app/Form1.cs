﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace pulseclicker_gui
{
    public partial class Form1 : Form
    {

        private const string RegistryKey = "Software\\HKEY_CURRENT_USER\\lockapp";
        private const string RegistryValue = "locked";



        public Form1()
        {
            InitializeComponent();
            LoadSettings();
        }

        private void LoadSettings()
        {
           
            RegistryKey key = Registry.CurrentUser.OpenSubKey(RegistryKey);
            if (key != null)
            {
               
                object value = key.GetValue(RegistryValue);
                if (value != null && value.ToString() == "1")
                {
               
                    Close();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            RegistryKey key = Registry.CurrentUser.CreateSubKey(RegistryKey);
            if (key != null)
            {
                key.SetValue(RegistryValue, "1");
                key.Close();
            }
            MessageBox.Show("app got locked");
        }
    }
}
