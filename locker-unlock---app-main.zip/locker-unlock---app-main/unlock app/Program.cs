﻿using Microsoft.Win32;
using System;

class Program
{
    static void Main(string[] args)
    {
        string registryPath = @"Software\HKEY_CURRENT_USER\lockapp";
        try
        {
            using (RegistryKey key = Registry.CurrentUser.OpenSubKey(registryPath, true))
            { 
                if (key != null)
                {
                    key.SetValue("locked", 0);
                    Console.WriteLine("app got unlocked");
                }
                else
                {
                    Console.WriteLine("registre key dont exist");
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("error : " + ex.Message);
        }
        Console.ReadLine();
    }
}
